# encoding: utf-8

module Cri

  # The current Cri version.
  VERSION = '2.6.1'

end
