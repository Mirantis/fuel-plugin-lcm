# encoding: utf-8

module Cri::CoreExtensions
end

require 'cri/core_ext/string'

class String
  include Cri::CoreExtensions::String
end
