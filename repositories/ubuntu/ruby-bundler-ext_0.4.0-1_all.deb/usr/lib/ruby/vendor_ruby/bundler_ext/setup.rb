gemfile = ENV['BEXT_GEMFILE'] || 'Gemfile.in'
BundlerExt.system_setup gemfile, :all
