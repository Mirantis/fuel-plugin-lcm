module BundlerExt
  VERSION = '0.4.0'
end
