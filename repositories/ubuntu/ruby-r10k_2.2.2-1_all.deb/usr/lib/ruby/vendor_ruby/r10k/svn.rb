module R10K
  module SVN
    require 'r10k/svn/working_dir'
    require 'r10k/svn/remote'
  end
end
