module R10K
  VERSION = '2.2.2'
end
