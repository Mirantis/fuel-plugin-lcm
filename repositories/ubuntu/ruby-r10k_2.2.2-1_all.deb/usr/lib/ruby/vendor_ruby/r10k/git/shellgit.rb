module R10K
  module Git
    module ShellGit
      require 'r10k/git/shellgit/bare_repository'
      require 'r10k/git/shellgit/working_repository'
      require 'r10k/git/shellgit/thin_repository'
    end
  end
end
