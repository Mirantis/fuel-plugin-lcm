module R10K
  module Action
    module Deploy
      require 'r10k/action/deploy/environment'
      require 'r10k/action/deploy/module'
      require 'r10k/action/deploy/display'
    end
  end
end
