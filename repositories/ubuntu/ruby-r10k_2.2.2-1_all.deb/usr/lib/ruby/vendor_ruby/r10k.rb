module R10K; end

require 'r10k/version'
require 'r10k/logging'
