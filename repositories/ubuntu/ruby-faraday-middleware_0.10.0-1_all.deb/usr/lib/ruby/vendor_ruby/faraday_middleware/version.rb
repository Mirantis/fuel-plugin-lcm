module FaradayMiddleware
  VERSION = "0.10.0" unless defined?(FaradayMiddleware::VERSION)
end
