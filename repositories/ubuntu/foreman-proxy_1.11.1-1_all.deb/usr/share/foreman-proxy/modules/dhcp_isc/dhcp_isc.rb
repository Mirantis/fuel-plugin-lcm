require 'dhcp_common/dhcp_common'
require 'dhcp_isc/dhcp_isc_plugin'
