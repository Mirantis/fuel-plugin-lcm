module Proxy::Realm
  class Client
    include Proxy::Log
    include Proxy::Util
  end
end