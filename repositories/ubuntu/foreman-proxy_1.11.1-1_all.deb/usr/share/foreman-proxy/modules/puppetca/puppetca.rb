require 'puppetca/puppetca_plugin'

module Proxy::PuppetCa; end
