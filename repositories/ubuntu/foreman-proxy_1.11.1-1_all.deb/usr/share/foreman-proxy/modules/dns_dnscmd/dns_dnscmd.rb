require 'dns_dnscmd/dns_dnscmd_plugin'
