require 'tftp/tftp_plugin'
module Proxy::TFTP; end