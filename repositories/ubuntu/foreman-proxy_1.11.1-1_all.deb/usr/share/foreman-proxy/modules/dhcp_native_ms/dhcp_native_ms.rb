require 'dhcp_common/dhcp_common'
require 'dhcp_native_ms/dhcp_native_ms_plugin'
