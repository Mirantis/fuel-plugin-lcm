group :puppet, :puppetca do
  gem 'puppet', '< 5.0.0'
  gem 'ruby-augeas', :require => 'augeas'
end
