group :krb5 do
  gem 'rkerberos', '>= 0.1.1'
  gem 'gssapi'
end
