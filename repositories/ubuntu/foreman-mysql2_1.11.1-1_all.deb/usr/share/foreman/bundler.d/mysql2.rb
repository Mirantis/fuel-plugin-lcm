group :mysql2 do
  gem 'mysql2', '~> 0.3.10'
end
