require 'backports/1.9.1/symbol/succ'
