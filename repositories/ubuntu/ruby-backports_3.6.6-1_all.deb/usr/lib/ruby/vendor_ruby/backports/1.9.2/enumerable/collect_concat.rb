require 'backports/1.9.2/enumerable/flat_map'
