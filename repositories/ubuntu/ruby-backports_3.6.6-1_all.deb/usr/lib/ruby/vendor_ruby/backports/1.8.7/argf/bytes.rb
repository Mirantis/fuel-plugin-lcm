require 'backports/1.8.7/argf/each_byte'
