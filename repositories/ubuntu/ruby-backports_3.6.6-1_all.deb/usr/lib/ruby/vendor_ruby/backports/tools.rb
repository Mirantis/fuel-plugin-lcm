# Methods used internally by the backports.
require 'backports/tools/require_relative_dir'
Backports.require_relative_dir
