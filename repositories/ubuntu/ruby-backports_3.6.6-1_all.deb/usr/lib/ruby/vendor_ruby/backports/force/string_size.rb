require 'backports/force/string_length'
