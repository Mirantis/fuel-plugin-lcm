require 'sinatra/contrib'
Sinatra.register Sinatra::Contrib::All
