module ApipieBindings
  def self.version
    @version ||= Gem::Version.new '0.0.16'
  end
end
