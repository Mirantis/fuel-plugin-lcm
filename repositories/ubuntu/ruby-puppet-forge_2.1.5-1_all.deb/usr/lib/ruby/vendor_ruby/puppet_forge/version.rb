module PuppetForge
  VERSION = '2.1.5' # Library version
end
